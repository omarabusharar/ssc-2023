import SwiftUI
struct BreatherView: View {
    @State var isInhale:Bool = false
    @State var reflectMins: Int = 30
    @State var hasBegun:Bool = false
    @State var showSheet = false
    var timeOptions = [30,60,90,120]
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    var body: some View {
        VStack {
            Spacer()
            HStack {
                ForEach(1..<4) { sizer in
                    VStack {
                        ForEach(1..<4, id: \.self) { x in
                            BreatheCircle(isBig: $isInhale)
                        }
                    }  .frame(width: isInhale ? CGFloat((120/sizer)) : nil, height: isInhale ? CGFloat((120/sizer)*3) : nil)
                }
                VStack {
                    BreatheCircle(isBig: $isInhale, size1: 40, size2: .infinity)
                    Spacer()
                    Circle()
                        .foregroundStyle(isInhale ? Color.blue.gradient : Color.green.gradient)
                        .animation(.linear(duration: 5), value: isInhale)
                        .onReceive(timer, perform: { _ in
                            if hasBegun && reflectMins != 0 {
                                if reflectMins > 0 {
                                    reflectMins -= 1
                                }
                                if reflectMins % 5 == 0 && timeOptions.contains(reflectMins) == false {
                                    isInhale.toggle()
                                }
                                if timeOptions.contains(reflectMins + 1) {
                                    isInhale = true
                                }
                            } else if timeOptions.contains(reflectMins) == false {
                                reflectMins = 30
                                showSheet = true
                                hasBegun = false
                            }
                        })
                        .alert("Breathing Session Completed", isPresented: $showSheet, actions: {
                            Button("OK", action: {
                                isInhale = false
                            })
                        }, message: {
                            Text("Great job!")
                                .onAppear() {
                                    isInhale = false
                                }
                        })
                    Spacer()
                    BreatheCircle(isBig: $isInhale, size1: 40, size2: .infinity)
                }
                ForEach((1..<4)) { sizer in
                    VStack {
                        ForEach(1..<4, id: \.self) { x in
                            BreatheCircle(isBig: $isInhale)
                        }
                    }  .frame(width: isInhale ? CGFloat((40*sizer)) : nil, height: isInhale ? CGFloat((40*sizer)*3) : nil)
                }
            }
            HStack {
                HStack {
                        VStack(alignment: .leading) {
                            Text(!hasBegun ? "Lower your stress with some deep breaths." : (isInhale ? "Inhale" : "Exhale"))
                                .fontWeight(.bold)
                                .font(.largeTitle)
                                .animation(.linear, value: isInhale)
                            Text(hasBegun ? "\(reflectMins) seconds left": "Go to the next page to find out other reasons you should deep breathe.")
                                .foregroundColor(.gray)
                        }
                    Spacer()
                    VStack {
                        Picker("Seconds", selection: $reflectMins, content: {
                            ForEach(timeOptions, id: \.self, content: { time in
                                Text("  \(time) seconds  ")
                            })
                        })
                        .disabled(hasBegun)
                        .tint(.orange)
                        Button(action: {
                            hasBegun.toggle()
                        }, label: {
                            HStack {
                                Spacer()
                                Label(hasBegun ? "Stop" : "Start", systemImage: hasBegun ? "xmark" : "checkmark")
                                Spacer()
                            }
                        })
                        .tint(hasBegun ? .red : .green)
                    }
                    .frame(width: 150)
                    .buttonStyle(.bordered)
                } .padding()
            } .background(.thinMaterial)
                .animation(.easeInOut, value: hasBegun)
                .frame(alignment: .bottom)
        } .navigationTitle("Deep Breathing")
    }
}
struct BreatheCircle:View {
    @Binding var isBig:Bool
    var size1:CGFloat = .infinity
    var size2:CGFloat = .infinity
    var body: some View {
        Spacer()
        Circle()
            .foregroundColor(isBig ? .blue : .green)
            .animation(.linear(duration: 5), value: isBig)
            .opacity(0.4)
            .frame(width: isBig ? size1 : size2, height: isBig ? size1 : size2)
        Spacer()
    }
}
