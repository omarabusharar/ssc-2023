import SwiftUI

struct PageView: View {
    @Binding var selection:Int?
    @Binding var progress:Double
    @State var page:Int = 0
    @State var finalPage = 0
    @State var hideButton = false
    @Binding var columnVisibility: NavigationSplitViewVisibility
    let titles = ["Mentality","Mental Health","Mental Hazards","Mental Illness","Mental Maintence","Conclusion"]
    let subtitles = ["What is it and why does it matter?","How you can be harmed mentally.","The dire consequences of Mental Harm","How to keep your mind in tip-top shape to prevent harm.","Time to wrap-up! Take a Quiz to Recap!"]
    let icons = ["brain","brain.head.profile","exclamationmark.triangle","heart.slash","wrench.and.screwdriver","checkmark.circle"]
    let finalPages = [1,1,4,1,4,5]
    let colors:Array<Color> = [.pink,.yellow,.red,.orange,.green]
    var body: some View {
        VStack {
            EmptyView()
                .onChange(of: selection, perform: { _ in
                    page = 0
                })
            if page == 0 && selection != 0 {
                titlePage(title: titles[(selection ?? 0)], subtitle: subtitles[(selection ?? 0) - 1], icon: icons[(selection ?? 0)], color: colors[(selection ?? 0) - 1])
                    .onAppear(perform: {
                        finalPage = finalPages[selection ?? 0]
                    })
                    .navigationTitle("")
            } else {
                switch selection {
                    case 0:
                        threePointers(title: ["Mentality","Mental Health","Mental Hazards","Mental Maintence"], description: ["In this experience, you will learn about...","What is Mental Health and why does it matter?","Things which can harm your Mental Health, and their consequences.","How to keep your mind in tip-top shape to prevent harm."], icon: ["brain","brain.head.profile","exclamationmark.triangle","wrench.and.screwdriver"], color: [.pink,.pink,.yellow,.orange], optional: "Mentaility is a Landscape experience, please keep your iPad in landscape while using the app.")
                            .onAppear(perform: {
                                finalPage = 0
                            })
                    case 1:
                        if page == 1 {
                            ExplainerView(title: "What is Mental Health", text: ["Mental Health is our Emotional, Psychological, Social Well-Being. It is an important factor in every sector of our life, and it's important we maintain it in good health as downsides come if you neglect it.","At school or work, you depend on positive mental health as a way to be productive and cope with the strees from all the work you have been assigned. Being in a poor state of mental health while employed or at school leads to difficulty concentrating, poor decision making, being less productive and, being absent as you would be more likely to get sick and / or not feel well.","Mental Health also affects Finances as if you are unable to hold down a job due to stress it brings and not knowing how to treat that stress to keep you mentally healthy can lead to poor job performance and eventually unemployment.","As mental health influences a lot of our lives, the reverse can occur too. Mental Health can be influenced by various factors such as Trauma, Genetics, Violence, Exposure to Toxic Chemicals, or Loss.", "It is importantant to know how to maintain a positive mental health to live a good life. Mentaility will teach you all about what you need to know about Mental Health, click forward to learn more."], image: "brain")
                        } else {
                            Text("hello \(page)")
                        }
                    case 2:
                        switch page {
                            case 2:
                                ExplainerView(title: "Social Media", text: ["Social Media is a complex matter for our Mental Health. On one hand it encourages social connection between people who wouldve never likely met in reality. On the other hand there is a plethora of issues in Social Media such as Twitter, Facebook, or Instagram which can affect us severely mentally.","Doomscrolling is a big issue with social media, it is when you keep scrolling on a Social Media platform, but it is all filled up with negetive information and content. This negative content leads to many having feelings of hopelessness and uselessness, eventually potientially evolving into depression, anxiety, social isolation, or other mental illnesses.","Time spent performing activities such as doomscrolling or just scrolling too much on social media can cause you to be addicted and for your sleep to be disrupted. Individually or combined, these two factors can cause a range of mental issues such as anxiety, depression, and more.","Comparsion of Social Lives is a big part of Social Media. Some people post to share what they did for the day, while others post a glorified version of their lives to appear better than people who follow them on the social platform. For the viewer of said content, it can lead to feeling lonely and inferior as the viewer doesn't have a life similar to the one shared on social media. The feeling of loneliness is further highlighted with FOMO (fear of missing out), seeing notable activity on social media can make one feel left out and isolated from those they follow. To conclude, Social Comparision combined with FOMO could lead to a poor mental state of low self worth and respect."], image: "globe", color: .yellow)
                            case 3:
                                ExplainerView(title: "Trauma", text: ["Trauma is when one experiences an event where something horrific or violent happened and afterward is stuck in your head. These experiences are emotionally or physically distressing and that overwhelm an individual's ability to cope. Trauma is something many have had to deal with in the past and  it affects how they live in notable ways.","Traumatic experiences such as Physical or Sexual Abuse, VIolence, Car accidents, have an immediate effect on you physically, but also affects you mentally. Trauma can leave you with PTSD, Post Traumatic Stress Disorder, where you get flashblacks to the event that caused it, you avoid thinking about those events, lost interest in activities you used to find enjoyable and being full of anxiety a lot of the time.","Trauma can also leave you with Depression, Anxiety, or make you turn to abuse of substances to cope from the effects of the event."], image: "clock.badge.exclamationmark.fill", color: .yellow)
                            case 4:
                                threePointers(title: ["Mental Hazards","Lack of Sleep","Social Isolation","Poor Diet"], description: ["include...","A poor sleep schedule can lead to an absent mental state and a higher chance of depression or anxiety.","Being lonely causes cognative decline and can give you depression, dementia, or anxiety as we are social creatures meant to comunnicate.","A poor diet lacking in optimal nutrients can lead to depression, anxiety, and slow your reaction time."], icon: ["exclamationmark.triangle","bed.double","person.2.slash","fork.knife"], color: [.yellow,.indigo,.blue,.cyan])
                            default:
                                ExplainerView(title: "What is a Mental Hazard?", text: ["A Mental Health Hazard is any condition or event that can affect your mental well-being negetively. Some are minor, while others are more severe. With this section of the Mentality app, we will look at some of these hazards, to ensure you could avoid hazards in your life for  keeping a better mental state."], image: "exclamationmark.triangle", color: .yellow)
                        }
                    case 3:
                        threePointers(title: ["Mental Illness","Depression","Anxiety","Bipolar Disorder"], description: ["Illnesses to get with poor mental health include...","Depression is when you are in a depressed mood and dont enjoy any of what you do. There is an increased risk of suicide, but there is some treatment available. 36.4% of students have depression.","Anxiety is when you have excessive fear and worry. It can cause Insomnia, Not being able to concentrate, and a fast heart beat. Can be cured. 41.6% of students have Anxiety","Bipolar can cause suddent shifts in one's mood, concentration, energy and activity levels. This makes it hard to do daily tasks. Can be treated to reduce effect."], icon: ["heart.slash","peacesign","clock.badge.exclamationmark","face.dashed"], color: [.red,.purple,.pink,.yellow])
                    case 4:
                        // Complete
                        switch page {
                            case 1:
                                BreatherView()
                            case 2:
                                threePointers(title: ["Deep Breathing","Calm Yourself","Relax","Reflect"], description: ["A wonderful way to improve your mental state! With it, you can...","Calm down during moments of anger, to maintain stability in your mind","Improve your state by putting your mind at ease, allowing you to relax","Allowing you to reflect and improve your life"], icon: ["lungs","smiley.fill","person.line.dotted.person","hand.thumbsup"], color: [.blue,.indigo,.cyan,.mint])
                                    .navigationTitle("")
                            case 3:
                                DiaryView()
                            case 4:
                                threePointers(title: ["Mental Maintence","Take a Hike","Talk to others","Sleep Well"], description: ["Other ways you can keep your mind healthy is...","Taking a hike places you in a peaceful enviroment where you can reflect and enjoy nature. Studies show that hiking outside can help prevent mental illness and take you away from negative thoughts.","Opening up to others can help you get rid of negative feelings, relieve stress, and also help you live longer. Studies show that strong social ties lead to a longer lifespan.","Sleep repairs your body mentally and physically It's vital for a healthy mind. Sleep affects your mood, thinking, and how you behave. Being sleep deprived and awake for 24 hours is like being drunk with a BAC of 0.1, for context, drunk driving is BAC 0.08%. Doctors recommend at least 7 hours of sleep for adults."], icon: ["wrench.and.screwdriver","mountain.2","person.line.dotted.person","bed.double"], color: [.orange,.red,.yellow,.green], width: 800)
                            default:
                                VStack {
                                    Text("You're not supposed to be here?")
                                    Button("Click me to go back to the first page of this section", action: {
                                        page = 1
                                    })
                                }
                        }
                    case 5:
                        if page == 1 {
                            ConclusionView(question: "What is Mental Health?", answer: "Emotional, Psychological, Social Well-Being", options: ["Emotional, Psychological, Social Well-Being","A sign of weakness","Psychological Well-Being","How smart you are"],hideButton: $hideButton)
                                .onAppear(perform: {
                                    scene.size = CGSize(width: 2046, height: 1536)
                                    scene.scaleMode = .resizeFill
                                    scene.attempts = 0
                                    scene.hideNext = true
                                    hideButton = true
                                    scene.removeAllChildren()
                                    
                                })
                                .onDisappear(perform: {
                                    if page > 2 || selection != 5 {
                                        hideButton = false
                                    }
                                })
                                .onReceive(NotificationCenter.default.publisher(for: NSNotification.gamedidfinish)) { _ in
                                    hideButton = false
                                }
                        } else if page == 2 {
                            ConclusionView(question: "Which Mental Hazard affects almost everyone?", answer: "Stress", options: ["Stress","Substance Abuse","Social Isolation","Violence"],hideButton: $hideButton)
                                .onAppear(perform: {
                                    scene.size = CGSize(width: 2046, height: 1536)
                                    scene.scaleMode = .resizeFill
                                    scene.attempts = 0
                                    scene.hideNext = true
                                    hideButton = true
                                    scene.removeAllChildren()
                                    
                                })
                                .onDisappear(perform: {
                                    if selection != 5 {
                                        hideButton = false
                                    }
                                })
                                .onReceive(NotificationCenter.default.publisher(for: NSNotification.gamedidfinish)) { _ in
                                    hideButton = false
                                }
                        } else if page == 3 {
                            ConclusionView(question: "Which Mental Illness is prevalent among Students", answer: "Anxiety", options: ["Depression","Biopolar Disorder","Anxiety","PTSD"],hideButton: $hideButton)
                                .onAppear(perform: {
                                    scene.size = CGSize(width: 2046, height: 1536)
                                    scene.scaleMode = .resizeFill
                                    scene.attempts = 0
                                    scene.hideNext = true
                                    hideButton = true
                                    scene.removeAllChildren()
                                    
                                })
                                .onDisappear(perform: {
                                    if selection != 5 {
                                        hideButton = false
                                    }
                                })
                                .onReceive(NotificationCenter.default.publisher(for: NSNotification.gamedidfinish)) { _ in
                                    hideButton = false
                                }
                        } else if page == 4 {
                            ConclusionView(question: "What can you do to be mentally healthy?", answer: "Taking a hike", options: ["Social Media","Avoiding negetive emotions","Drugs or Alcohol","Taking a hike"],hideButton: $hideButton)
                                .onAppear(perform: {
                                    scene.size = CGSize(width: 2046, height: 1536)
                                    scene.scaleMode = .resizeFill
                                    scene.attempts = 0
                                    scene.hideNext = true
                                    hideButton = true
                                    scene.removeAllChildren()
                                    
                                })
                                .onDisappear(perform: {
                                    if selection != 5 {
                                        hideButton = false
                                    }
                                })
                                .onReceive(NotificationCenter.default.publisher(for: NSNotification.gamedidfinish)) { _ in
                                    hideButton = false
                                }
                        } else {
                            Thanks()
                        }
                    default:
                        threePointers(title: ["Mentality","Mental Health","Mental Hazards","Mental Maintence"], description: ["In this experience, you will learn about...","What is Mental Health and why does it matter?","Things which can harm your Mental Health, and their consequences.","How to keep your mind in tip-top shape to prevent harm."], icon: ["brain","brain.head.profile","exclamationmark.triangle","eye.slash"], color: [.pink,.yellow,.green])
                }
            }
        }
        .onChange(of: selection, perform: { _ in
            page = 0
        })
        .toolbar(content: {
            ToolbarItem(placement: .bottomBar, content: {
                if selection != 0 {
                    Button(action: {
                        if page != 0 {
                            page -= 1
                        } else {
                            selection! -= 1
                        }
                    }, label: {
                        Label("Backward", systemImage: "arrow.backward")
                    })
                    .buttonStyle(.bordered)
                    .buttonBorderShape(.capsule)
                    .tint((page == 0) ? .white : .blue)
                    .onChange(of: selection, perform: { s in
                        page = 0
                    })
                }
            })
            ToolbarItem(placement: .bottomBar,content: {
                if finalPage != page && hideButton == false {
                    Button(action: {
                        page += 1
                    }, label: {
                        Label("Forward", systemImage: "arrow.forward")
                    })
                    .buttonStyle(.bordered)
                    .buttonBorderShape(.capsule)
                    .tint((page == 0) ? .white : .blue)
                } else if hideButton == false {
                    if page < 6 && progress != 6 {
                        Button(action: {
                            if selection != 5 {
                                selection! += 1
                                page = 0
                            }
                            if progress != 6 {
                                progress += 1
                            }
                        }, label: {
                            Label("Complete Section", systemImage: "checkmark")
                        })
                        .buttonStyle(.bordered)
                        .buttonBorderShape(.capsule)
                        .tint(.green)
                    }
                }
            })
        })
    }
}

struct titlePage: View {
    var title: String
    var subtitle: String
    var icon: String
    var color: Color
    var body: some View {
        ZStack {
            Rectangle()
                .fill(color.gradient)
                .edgesIgnoringSafeArea(.all)
            VStack {
                RoundedIcon(icon: icon, size: 200, color: color,reverse: true)
                    .padding()
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                Text(subtitle)
                    .brightness(2)
            } .foregroundColor(.white)
        }
    }
}
