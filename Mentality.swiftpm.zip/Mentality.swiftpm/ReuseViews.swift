
import SwiftUI

// enter other ways to maintence mental health
struct threePointers: View {
    let title:[String]
    let description:[String]
    let icon:[String]
    let color:[Color]
    var optional:String? = nil
    var width: CGFloat = 550
    var body: some View {
        VStack {
            VStack {
                RoundedIcon(icon: icon.first!, size: 150, color: color.first!, reverse: true)
                    .shadow(radius: 5)
                Text(title[0])
                    .font(.largeTitle)
                    .fontWeight(.bold)
            } .frame(alignment: .center)
            Text(description[0])
                .foregroundColor(.gray)
            Spacer()
            VStack(alignment: .leading) {
                Spacer()
                ForEach(1..<4) { i in
                    HStack(alignment: .center) {
                        RoundedIcon(icon: icon[i], size: 90, color: color[i])
                            .padding(.trailing)
                        VStack(alignment: .leading) {
                            Text(title[i])
                                .fontWeight(.bold)
                            Text(description[i])
                                .foregroundColor(.gray)
                        }
                    } .padding(.vertical, 5)
                    Spacer()
                }
            }
            .frame(width: width)
            Spacer()
            Text(optional ?? "")
                .font(.headline)
                .padding(.all)
       
            
    }
    }
}

struct RoundedIcon: View {
    var icon:String
    var size: CGFloat
    var color: Color
    var reverse = false
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25 * (size / 100))
                .frame(width: size,height: size)
                .foregroundStyle(!reverse ? color.gradient : Color.white.gradient)
                .overlay(alignment: .center, content: {
                    Image(systemName: icon)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.all,(20 * (size / 100)))
                        .foregroundStyle(!reverse ? Color.white.gradient : color.gradient)
                })
        }
    }
}

struct LearningProgress: View {
    @Binding var progress:Double
    @State var showAlert:Bool = false
    var body: some View {
        HStack {
                ProgressView((progress == 6) ? "Learning Complete" : "Learning Progress", value: progress, total: 6)
                    .tint((progress == 6) ? .green : .blue)
                    .animation(.easeInOut(duration: 0.5), value: progress)
            Button(role: .destructive, action: {
                showAlert.toggle()
            }, label: {
                Image(systemName: "trash")
                    .foregroundColor(.red)
            })
            .alert("Reset Learning Progress?", isPresented: $showAlert, actions: {
                Button("Cancel", role: .cancel) { }
                Button("OK", role: .destructive) {
                    progress = 0.0
                }
            }, message: {
                Text("Clicking \"OK\" will reset your progress.")
            })
        }
    }
}


