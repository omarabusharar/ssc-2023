import SwiftUI
struct ExplainerView: View {
    var title:String
    var text:[String]
    var image:String = "brain"
    var color:Color = .pink
    var body: some View {
        GeometryReader { geometry in
                HStack {
                    ScrollView {
                        VStack(alignment: .center) {
                            ForEach(text, id: \.self, content: { t in
                                Text(t)
                                    .font(.body)
                                    .padding(.horizontal)
                                Spacer()
                                    .frame(height: 50)
                            })
                        }
                    }
                        .frame(width: geometry.size.width * 5 / 8)
                        ZStack {
                            Rectangle()
                                .foregroundStyle(color.gradient)
                                .ignoresSafeArea(.all)
                            RoundedIcon(icon: image, size: 150, color: color,reverse: true)
                                .navigationTitle(title)
                        }
                    .frame(width: geometry.size.width * 3 / 8)
                }
        }
    }
}



struct LeftSide: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .center) {
                Text("What ia")
                    .font(.title)
                    .fontWeight(.bold)
                    .navigationTitle("What is Mental Health?")
                Spacer()
                    .frame(height: 500)
                Text("howdy")
            }
        }
    }
}
