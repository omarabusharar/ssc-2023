
import Foundation
struct Illness {
    var name: String
    var description:String
    var symptoms:String
    var icon: String
}
struct Xection {
    var id:Int
    var name:String
    var icon:String
}
let sections:[Xection] = [
    .init(id: 0, name: "Welcome", icon: "hand.wave"),
    .init(id: 1, name: "Health", icon: "brain.head.profile"),
    .init(id: 2, name: "Hazards", icon: "exclamationmark.triangle"),
    .init(id: 3, name: "Illness", icon: "heart.slash"),
    .init(id: 4, name: "Maintenance", icon: "wrench.and.screwdriver"),
    .init(id: 5, name: "Conclusion", icon: "checkmark.circle")
]
