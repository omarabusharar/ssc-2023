import SwiftUI
import SpriteKit
let scene = QuizScene.shared
struct ConclusionView: View {
    var question: String
    var answer:String
    var options:Array<String>
    @Binding var hideButton:Bool
    var body: some View {
        SpriteView(scene: scene)
            .onAppear(perform: {
                scene.size = CGSize(width: 2046, height: 1536)
                scene.scaleMode = .resizeFill
                scene.question = question
                scene.answer = answer
                scene.options = options
                scene.attempts = 0
                scene.hideNext = true
                hideButton = true
            })
            .ignoresSafeArea(.all)
            .navigationBarTitleDisplayMode(.inline)
            
    }
}
class QuizScene: SKScene, SKPhysicsContactDelegate {
    static var shared = QuizScene()
    private var currentNode: SKNode?
    var question:String = "d"
    var answer:String = "a"
    var hideNext = true
     var options:Array<String> = ["a","b"]
    let optionsCategory: UInt32 = 0x1 << 0
    let answerCategory: UInt32 = 0x1 << 1
    let uselessCategory: UInt32 = 0x2 << 2
    var attempts = 0
    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
        let questionlabel = SKLabelNode(fontNamed: "Georgia")
        questionlabel.text = question
        questionlabel.position = CGPoint(x: frame.minX + 288, y: frame.maxY - 116)
        questionlabel.fontSize = 25
        questionlabel.fontColor = .yellow
        questionlabel.name = "question"
        addChild(questionlabel)
        let instruction = SKLabelNode(fontNamed: "Georgia")
        instruction.text = "Drag the correct answer to the box."
        instruction.fontColor = .yellow
        instruction.fontSize = 20
        instruction.name = "instruction"
        instruction.position = CGPoint(x: frame.minX + 256, y: frame.maxY - 166)
        addChild(instruction)
        let answerbox = SKShapeNode()
        answerbox.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -142, width: 512, height: 128), cornerRadius: 30).cgPath
        answerbox.name = "answerbox"
        answerbox.strokeColor = .yellow
        answerbox.position = CGPoint(x: frame.maxX - 448, y: frame.maxY - 42)
        answerbox.physicsBody = SKPhysicsBody(polygonFrom: UIBezierPath(roundedRect: CGRect(x: -192, y: -168, width: 512, height: 128), cornerRadius: 64).cgPath)
        answerbox.physicsBody?.isDynamic = false
        answerbox.physicsBody?.categoryBitMask = answerCategory
        answerbox.physicsBody?.collisionBitMask = optionsCategory
        addChild(answerbox)
        for o in options {
            let optionsSprite = SKLabelNode(fontNamed: "Georgia")
            optionsSprite.name = "drag \(options[options.firstIndex(of: o)!])"
            optionsSprite.text = "\(1 + options.firstIndex(of: o)!)) \(options[options.firstIndex(of: o)!])"
            optionsSprite.fontSize = 30
            optionsSprite.fontColor = .systemMint
            optionsSprite.physicsBody = SKPhysicsBody(circleOfRadius: 40)
            optionsSprite.physicsBody?.isDynamic = true
            optionsSprite.physicsBody?.categoryBitMask = optionsCategory
            optionsSprite.physicsBody?.collisionBitMask = answerCategory
            optionsSprite.physicsBody!.contactTestBitMask = answerCategory
            optionsSprite.physicsBody?.affectedByGravity = false
            optionsSprite.position.x = frame.midX
            optionsSprite.position.y = CGFloat((340 - 70 * options.firstIndex(of: o)!))
            addChild(optionsSprite)
        }
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let location = touch.location(in: self)
            let touchedNodes = self.nodes(at: location)
            for node in touchedNodes.reversed() {
                if ((node.name?.contains("drag")) == true ) {
                    self.currentNode = node

                }
            }
            self.currentNode?.physicsBody?.isDynamic = false
            
        }
        if let touch = touches.first, let node = self.currentNode {
            let touchLocation = touch.location(in: self)
            node.position = touchLocation
        }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first, let node = self.currentNode {
            let touchLocation = touch.location(in: self)
            node.position = touchLocation
        }
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.currentNode?.physicsBody?.isDynamic = true
        self.currentNode = nil
        
    }
    
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.currentNode?.physicsBody?.isDynamic = true
        self.currentNode = nil
        
    }
    func didBegin(_ contact: SKPhysicsContact) {
        let incorrect = SKLabelNode(fontNamed: "Georgia")
        incorrect.text = "Try Again"
        incorrect.fontSize = 60
        incorrect.fontColor = .red
        incorrect.position = CGPoint(x: frame.maxX - 324, y: frame.maxY - 140)
        incorrect.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 512, height: 128))
        incorrect.physicsBody?.isDynamic = false
        incorrect.physicsBody?.categoryBitMask = uselessCategory
        incorrect.physicsBody?.affectedByGravity = false
        let correct = SKLabelNode(fontNamed: "Georgia")
        correct.text = "Correct!"
        correct.fontSize = 60
        correct.fontColor = .green
        correct.position = CGPoint(x: frame.maxX - 324, y: frame.maxY - 140)
        print("a")
        if contact.bodyA.categoryBitMask == answerCategory || contact.bodyB.categoryBitMask == answerCategory && contact.bodyA.categoryBitMask == optionsCategory || contact.bodyB.categoryBitMask == optionsCategory {
            if contact.bodyA.node!.name! == "drag \(answer)" {
                contact.bodyA.node?.removeFromParent()
                let x = contact.bodyB.node as? SKShapeNode
                x?.fillColor = .green
                NotificationCenter.default.post(name: NSNotification.gamedidfinish, object: nil, userInfo: ["gamesDone": "nice"])
                addChild(correct)
                if attempts > 0 {
                    for child in self.children {
                        if child.physicsBody?.categoryBitMask == uselessCategory {
                            child.physicsBody?.affectedByGravity = true
                        }
                    }
                }

            } else if contact.bodyB.node!.name! == "drag \(answer)" {
                let x = contact.bodyA.node as? SKShapeNode
                contact.bodyB.node?.removeFromParent()
                x?.strokeColor = .green
                if attempts > 0 {
                    for child in self.children {
                        if child.physicsBody?.categoryBitMask == uselessCategory {
                            child.removeFromParent()
                        }
                    }
                }
                addChild(correct)
                NotificationCenter.default.post(name: NSNotification.gamedidfinish,
                                                object: nil, userInfo: ["gamesDone": "nice"])
            } else if contact.bodyB.node!.physicsBody?.categoryBitMask == answerCategory && hideNext {
                let x = contact.bodyB.node as? SKShapeNode
                x!.strokeColor = .red
                contact.bodyA.node?.removeFromParent()
                attempts += 1
                if attempts < 2 {
                    addChild(incorrect)
                }
            } else if contact.bodyA.node!.physicsBody?.categoryBitMask == answerCategory && hideNext {
                let x = contact.bodyA.node as? SKShapeNode
                x!.strokeColor = .red
                attempts += 1
                contact.bodyB.node?.removeFromParent()
                if attempts < 2 {
                    addChild(incorrect)
                }
            }
        }
    }
}
extension NSNotification {
    static let gamedidfinish = Notification.Name.init("gamesDone")
}
