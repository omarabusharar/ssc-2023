import SwiftUI

struct DiaryView: View {
    @State var title:String = ""
    @State var text:String = ""
    var body: some View {
        List() {
            Section(content: {
                HStack {
                    Spacer()
                    VStack(alignment: .center) {
                        VStack {
                            RoundedIcon(icon: "text.book.closed", size: 150, color: .orange, reverse: true)
                                .shadow(radius: 3)
                            Text("Diary")
                                .font(.largeTitle)
                                .fontWeight(.bold)
                        } .frame(alignment: .center)
                            .padding(.all)
                        Text("Destress and reflect on your day with a diary. Try writing an entry now!")
                            .foregroundColor(.gray)
                            .multilineTextAlignment(.center)
                    }
                    Spacer()
                }
            })
            Section(content: {
                TextField("Title", text: $title)
                TextEditor(text: $text)
            }, header: {
                Text("Entry")
            }, footer: {
                Text("Privacy Note: What you write will be wiped next page.")
            })
        }
      
    }
}

struct DiaryView_Previews: PreviewProvider {
    static var previews: some View {
        DiaryView()
    }
}
