
import SwiftUI

@main
struct Mental_HealthApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
