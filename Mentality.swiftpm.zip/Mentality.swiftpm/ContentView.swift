
import SwiftUI
// Main View Where All is Presented
struct ContentView: View {
    @State var detailSelection:Int? = 0
    @State var progress = 0.0
    @State var columnVisibility = NavigationSplitViewVisibility.doubleColumn
    var body: some View {
        NavigationSplitView(columnVisibility: $columnVisibility,sidebar: {
            List(sections, id: \.id, selection: $detailSelection) { section in
                    Label(section.name, systemImage: section.icon)
            }
            .listStyle(.sidebar)
            .navigationTitle("Mentality")
            .toolbar(content: {
                    ToolbarItem(placement: .status, content: {
                        LearningProgress(progress: $progress)
                    })
                })
            
        }, detail: {
            PageView(selection: $detailSelection, progress: $progress, columnVisibility: $columnVisibility)
                .onChange(of: detailSelection, perform: { _ in
                    columnVisibility = .detailOnly
                })
        })
    }
}
