import SwiftUI

struct Thanks: View {
    var body: some View {
        VStack {
            RoundedIcon(icon: "brain", size: 200, color: .pink,reverse: true)
                .padding()
            Text("Thank you for using Mentaility.")
                .font(.largeTitle)
                .fontWeight(.bold)
            Text("I enjoyed making it and hope you learned lots just like i have.")
        }
    }
}
